#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
전산팀 문서 중앙관리 시스템 - Excel → DB 마이그레이션 메인 스크립트

사용법:
    # 전체 실행 (파싱 + DB 삽입)
    python main.py --all
    
    # 파싱만 실행 (JSON 출력)
    python main.py --parse-only
    
    # 특정 모듈만 실행
    python main.py --module equipment
    python main.py --module users
    python main.py --module software
    
환경변수:
    DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
"""

import os
import sys
import json
import argparse
from datetime import datetime

# 파서 임포트
from parsers import (
    parse_all_equipment,
    parse_all_users,
    parse_all_equipment_credentials,
    parse_all_ip_allocation,
    parse_network_policy,
    parse_wireless_ap,
    parse_all_software_license,
    parse_sw_installation,
    parse_printer_consumable,
    parse_consumable_history,
    parse_all_it_requests,
    parse_payment,
    parse_regular_payment,
)


def get_file_paths(base_dir: str = '.') -> dict:
    """Excel 파일 경로 반환"""
    return {
        'ip_mac': os.path.join(base_dir, '02IP-MAC관리.xlsx'),
        'printer': os.path.join(base_dir, '01프린트관리대장.xlsx'),
        'software': os.path.join(base_dir, '03소프트웨어현황.xlsx'),
        'payment': os.path.join(base_dir, '05전산실정기지불자료.xlsx'),
        'request': os.path.join(base_dir, '06전산업무의뢰서접수.xlsx'),
    }


def parse_all(files: dict) -> dict:
    """모든 데이터 파싱"""
    print("=" * 60)
    print("Excel 파일 파싱 시작")
    print("=" * 60)
    
    results = {}
    
    # 1. 장비
    print("\n[1/10] 장비 데이터 파싱...")
    try:
        results['equipment'] = parse_all_equipment(files['ip_mac'], files['printer'])
        print(f"  → {len(results['equipment'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['equipment'] = []
    
    # 2. 사용자
    print("\n[2/10] 사용자 데이터 파싱...")
    try:
        users, user_credentials = parse_all_users(files['software'], files['ip_mac'])
        results['users'] = users
        results['user_credentials'] = user_credentials
        print(f"  → 사용자: {len(results['users'])}건, 인증정보: {len(results['user_credentials'])}건")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['users'] = []
        results['user_credentials'] = []
    
    # 3. 장비 인증정보
    print("\n[3/10] 장비 인증정보 파싱...")
    try:
        results['equipment_credentials'] = parse_all_equipment_credentials(files['ip_mac'])
        print(f"  → {len(results['equipment_credentials'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['equipment_credentials'] = []
    
    # 4. IP 할당
    print("\n[4/10] IP 할당 정보 파싱...")
    try:
        results['ip_allocation'] = parse_all_ip_allocation(files['ip_mac'])
        print(f"  → {len(results['ip_allocation'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['ip_allocation'] = []
    
    # 5. 소프트웨어 라이선스
    print("\n[5/10] 소프트웨어 라이선스 파싱...")
    try:
        results['software_license'] = parse_all_software_license(files['software'])
        print(f"  → {len(results['software_license'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['software_license'] = []
    
    # 6. SW 설치 현황
    print("\n[6/10] SW 설치 현황 파싱...")
    try:
        results['sw_installation'] = parse_sw_installation(files['software'])
        print(f"  → {len(results['sw_installation'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['sw_installation'] = []
    
    # 7. 프린터 소모품
    print("\n[7/10] 프린터 소모품 파싱...")
    try:
        results['printer_consumable'] = parse_printer_consumable(files['printer'])
        results['consumable_history'] = parse_consumable_history(files['printer'])
        print(f"  → 소모품: {len(results['printer_consumable'])}건, 이력: {len(results['consumable_history'])}건")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['printer_consumable'] = []
        results['consumable_history'] = []
    
    # 8. IT 요청
    print("\n[8/10] IT 업무 의뢰 파싱...")
    try:
        results['it_request'] = parse_all_it_requests(files['request'])
        print(f"  → {len(results['it_request'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['it_request'] = []
    
    # 9. 지출 내역
    print("\n[9/10] 지출 내역 파싱...")
    try:
        results['payment'] = parse_payment(files['payment'])
        print(f"  → {len(results['payment'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['payment'] = []
    
    # 10. 정기지불
    print("\n[10/10] 정기지불 항목 파싱...")
    try:
        results['regular_payment'] = parse_regular_payment(files['payment'])
        print(f"  → {len(results['regular_payment'])}건 파싱 완료")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['regular_payment'] = []
    
    # 추가: 네트워크 정책, 무선 AP
    print("\n[추가] 네트워크 정책 및 무선 AP 파싱...")
    try:
        results['network_policy'] = parse_network_policy(files['ip_mac'])
        results['wireless_ap'] = parse_wireless_ap(files['ip_mac'])
        print(f"  → 정책: {len(results['network_policy'])}건, AP: {len(results['wireless_ap'])}건")
    except Exception as e:
        print(f"  → 오류: {e}")
        results['network_policy'] = []
        results['wireless_ap'] = []
    
    return results


def insert_to_db(results: dict):
    """파싱 결과를 DB에 삽입"""
    from db_manager import DatabaseManager
    
    print("\n" + "=" * 60)
    print("데이터베이스 삽입 시작")
    print("=" * 60)
    
    db = DatabaseManager()
    
    try:
        db.connect()
        
        # 순서대로 삽입 (FK 의존성 고려)
        print("\n[1] 장비 데이터 삽입...")
        db.insert_equipment(results.get('equipment', []))
        
        print("\n[2] 사용자 데이터 삽입...")
        db.insert_users(results.get('users', []))
        
        print("\n[3] IP 할당 데이터 삽입...")
        db.insert_ip_allocation(results.get('ip_allocation', []))
        
        print("\n[4] 소프트웨어 라이선스 삽입...")
        db.insert_software_license(results.get('software_license', []))
        
        print("\n[5] 프린터 소모품 삽입...")
        db.insert_printer_consumable(results.get('printer_consumable', []))
        
        print("\n[6] 소모품 교체 이력 삽입...")
        db.insert_consumable_history(results.get('consumable_history', []))
        
        print("\n[7] IT 요청 삽입...")
        db.insert_it_request(results.get('it_request', []))
        
        print("\n[8] 지출 내역 삽입...")
        db.insert_payment(results.get('payment', []))
        
        print("\n[9] 정기지불 항목 삽입...")
        db.insert_regular_payment(results.get('regular_payment', []))
        
        print("\n[10] 네트워크 정책 삽입...")
        db.insert_network_policy(results.get('network_policy', []))
        
        print("\n[11] 무선 AP 삽입...")
        db.insert_wireless_ap(results.get('wireless_ap', []))
        
        print("\n" + "=" * 60)
        print("✓ 데이터베이스 삽입 완료")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n✗ 오류 발생: {e}")
        db.rollback()
        raise
    
    finally:
        db.close()


def print_summary(results: dict):
    """파싱 결과 요약 출력"""
    print("\n" + "=" * 60)
    print("파싱 결과 요약")
    print("=" * 60)
    
    total = 0
    for key, data in results.items():
        count = len(data) if data else 0
        total += count
        print(f"  {key:25s}: {count:5d}건")
    
    print("-" * 60)
    print(f"  {'총계':25s}: {total:5d}건")
    print("=" * 60)


def save_to_json(results: dict, output_file: str):
    """결과를 JSON 파일로 저장"""
    # datetime 객체 처리
    def default_serializer(obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return str(obj)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=default_serializer)
    
    print(f"\n✓ 결과 저장: {output_file}")


def main():
    parser = argparse.ArgumentParser(description='전산팀 문서 중앙관리 시스템 - Excel → DB 마이그레이션')
    parser.add_argument('--all', action='store_true', help='전체 실행 (파싱 + DB 삽입)')
    parser.add_argument('--parse-only', action='store_true', help='파싱만 실행')
    parser.add_argument('--module', type=str, help='특정 모듈만 실행')
    parser.add_argument('--input-dir', type=str, default='.', help='Excel 파일 디렉토리')
    parser.add_argument('--output', type=str, default='parsed_data.json', help='JSON 출력 파일')
    
    args = parser.parse_args()
    
    # 기본값: --all
    if not any([args.all, args.parse_only, args.module]):
        args.parse_only = True
    
    # 파일 경로 확인
    files = get_file_paths(args.input_dir)
    
    print("=" * 60)
    print("전산팀 문서 중앙관리 시스템 - Excel → DB 마이그레이션")
    print(f"실행 시간: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    # 파싱 실행
    results = parse_all(files)
    
    # 요약 출력
    print_summary(results)
    
    # JSON 저장
    if args.parse_only or args.all:
        save_to_json(results, args.output)
    
    # DB 삽입
    if args.all:
        insert_to_db(results)
    
    print("\n✓ 작업 완료")


if __name__ == '__main__':
    main()
