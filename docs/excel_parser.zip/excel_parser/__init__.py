# -*- coding: utf-8 -*-
"""
전산팀 문서 중앙관리 시스템 - Excel 파서 패키지

주요 기능:
- Excel 파일에서 데이터 추출
- PostgreSQL DB로 데이터 마이그레이션
- 데이터 변환 및 정제

사용법:
    from excel_parser import parse_all
    from excel_parser.db_manager import DatabaseManager
"""

__version__ = '1.0.0'
__author__ = 'IT Team'

from .config import EXCEL_FILES, EQUIPMENT_CATEGORY_MAP
from .db_manager import DatabaseManager
