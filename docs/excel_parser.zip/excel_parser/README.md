# 전산팀 문서 중앙관리 시스템 - Excel 파서

Excel 파일에서 데이터를 추출하여 PostgreSQL 데이터베이스로 마이그레이션하는 Python 모듈입니다.

## 구조

```
excel_parser/
├── __init__.py           # 패키지 초기화
├── config.py             # 설정 파일
├── db_manager.py         # DB 연결 및 삽입 모듈
├── main.py               # 메인 실행 스크립트
├── requirements.txt      # Python 의존성
├── README.md             # 이 파일
└── parsers/              # 파서 모듈
    ├── __init__.py
    ├── common.py         # 공통 유틸리티
    ├── equipment.py      # 장비 파서
    ├── users.py          # 사용자/인증정보 파서
    ├── network.py        # IP/방화벽/AP 파서
    ├── software.py       # 소프트웨어 파서
    ├── printer.py        # 프린터 소모품 파서
    ├── request.py        # IT 요청 파서
    └── payment.py        # 지출/정기지불 파서
```

## 설치

```bash
cd excel_parser
pip install -r requirements.txt
```

## 사용법

### 1. 파싱만 실행 (JSON 출력)

```bash
python main.py --parse-only --input-dir /path/to/excel/files
```

### 2. 전체 실행 (파싱 + DB 삽입)

```bash
# 환경변수 설정
export DB_HOST=localhost
export DB_PORT=5432
export DB_NAME=it_manager
export DB_USER=postgres
export DB_PASSWORD=yourpassword

# 실행
python main.py --all --input-dir /path/to/excel/files
```

### 3. 특정 모듈만 테스트

```python
from parsers import parse_all_equipment

# 장비 데이터 파싱
equipment = parse_all_equipment('02IP-MAC관리.xlsx', '01프린트관리대장.xlsx')
print(f"파싱된 장비: {len(equipment)}건")
```

## 원본 Excel 파일

| 파일명 | 용도 | 대상 테이블 |
|-------|------|------------|
| 01프린트관리대장.xlsx | 프린터, 소모품 | equipment, printer_consumable, consumable_history |
| 02IP-MAC관리.xlsx | 장비, IP, 네트워크 | equipment, users, ip_allocation, network_policy, wireless_ap |
| 03소프트웨어현황.xlsx | 사용자, 라이선스 | users, software_license, sw_installation |
| 05전산실정기지불자료.xlsx | 지출 | payment, regular_payment |
| 06전산업무의뢰서접수.xlsx | IT 요청 | it_request |

## 데이터베이스

PostgreSQL 15개 테이블로 마이그레이션:

- **마스터**: equipment, users, software_license, printer_consumable
- **매핑/이력**: equipment_user, ip_allocation, sw_installation, consumable_history
- **인증정보**: user_credential, equipment_credential
- **업무**: it_request, payment, regular_payment
- **네트워크**: network_policy, wireless_ap

## 주의사항

1. Excel 파일이 암호로 보호된 경우 먼저 해제 필요
2. DB 삽입 전 `ddl_schema.sql` 실행하여 테이블 생성 필요
3. 인증정보(password 필드)는 암호화 저장 권장
