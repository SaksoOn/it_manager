# -*- coding: utf-8 -*-
"""
전산팀 문서 중앙관리 시스템 - 설정 파일
"""

# Excel 파일 경로
EXCEL_FILES = {
    'ip_mac': '02IP-MAC관리.xlsx',
    'printer': '01프린트관리대장.xlsx',
    'software': '03소프트웨어현황.xlsx',
    'payment': '05전산실정기지불자료.xlsx',
    'request': '06전산업무의뢰서접수.xlsx',
}

# 장비 카테고리 매핑
EQUIPMENT_CATEGORY_MAP = {
    'KHPC': '노트북',
    'KHN': '노트북',
    'KHD': 'PC',
    'KHP': '프린터',
    'KHL': '네트워크',
    'SVR': '서버',
    'Switch': '네트워크',
    'Swithc': '네트워크',  # 오타 대응
    'FIREWALL': '네트워크',
    'NAS': '서버',
}

# 네트워크 대역 매핑
NETWORK_ZONE_MAP = {
    'V10-DHCP': 'V10-DHCP',
    'V10-고정대역': 'V10-고정',
    'V40-폐쇄망': 'V40-폐쇄망',
    'V50-DHCP': 'V50-Guest',
    '2공장': '2공장',
}

# 장비 상태
EQUIPMENT_STATUS = ['사용중', '미사용', '폐기', '수리중']

# 사용자 상태
USER_STATUS = ['재직', '퇴사', '휴직']

# IT 요청 타입
REQUEST_TYPES = ['KHERP', 'VNERP', 'ETC']

# IT 요청 카테고리
REQUEST_CATEGORIES = ['신규개발', '기능개선', '오류수정', '구입', '수리', '기타']
