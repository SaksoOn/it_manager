# -*- coding: utf-8 -*-
"""
프린터 소모품(printer_consumable) 및 교체 이력(consumable_history) 파서
- 01프린트관리대장.xlsx
"""

import pandas as pd
import re
from typing import List, Dict, Tuple
from .common import clean_value, parse_day_from_cell, read_excel_sheet


def parse_printer_consumable(filepath: str) -> List[Dict]:
    """01프린트관리대장 - 관리대장 시트에서 소모품 마스터 파싱"""
    df = read_excel_sheet(filepath, '관리대장', header_row=0)
    
    consumables = {}
    for _, row in df.iterrows():
        consumable_code = clean_value(row.iloc[5])  # 토너
        model_name = clean_value(row.iloc[3])  # 제품명 (프린터 모델)
        
        if not consumable_code:
            continue
        
        # 헤더 행 건너뛰기
        if consumable_code == '토너':
            continue
        
        # 중복 체크 및 호환 모델 추가
        if consumable_code in consumables:
            if model_name:
                existing_models = consumables[consumable_code]['compatible_models']
                if existing_models:
                    if model_name not in existing_models:
                        consumables[consumable_code]['compatible_models'] = f"{existing_models}, {model_name}"
                else:
                    consumables[consumable_code]['compatible_models'] = model_name
        else:
            consumables[consumable_code] = {
                'consumable_code': consumable_code,
                'consumable_name': consumable_code,
                'consumable_type': '토너',
                'compatible_models': model_name,
                'unit_price': None,
            }
    
    return list(consumables.values())


def parse_consumable_history(filepath: str) -> List[Dict]:
    """
    01프린트관리대장 - 관리대장 시트에서 소모품 교체 이력 파싱
    
    컬럼 구조:
    - 0: 구분 (층)
    - 1: 설치부서
    - 2: 관리번호
    - 3: 제품명
    - 4: 사용IP
    - 5: 토너
    - 6~: 연도별 월 컬럼 (2018년 1월 ~ 2025년 12월)
    """
    df = read_excel_sheet(filepath, '관리대장', header_row=0)
    
    # 헤더 행에서 연도/월 정보 추출 (6번 컬럼부터)
    # 첫 번째 행: 연도 (2018년, 2019년 ...)
    # 두 번째 행: 월 (1월, 2월 ...)
    
    results = []
    
    # 헤더 분석을 위해 첫 두 행 확인
    year_row = df.iloc[0]
    month_row = df.iloc[1]
    
    # 연도-월 컬럼 매핑 생성
    year_month_map = {}
    current_year = None
    
    for col_idx in range(6, len(df.columns)):
        year_val = year_row.iloc[col_idx]
        month_val = month_row.iloc[col_idx]
        
        # 연도 업데이트
        if pd.notna(year_val):
            year_str = str(year_val)
            year_match = re.search(r'(\d{4})', year_str)
            if year_match:
                current_year = int(year_match.group(1))
        
        # 월 추출
        if pd.notna(month_val) and current_year:
            month_str = str(month_val)
            month_match = re.search(r'(\d{1,2})', month_str)
            if month_match:
                month = int(month_match.group(1))
                year_month_map[col_idx] = (current_year, month)
    
    # 데이터 행 처리 (3번째 행부터)
    for row_idx in range(2, len(df)):
        row = df.iloc[row_idx]
        
        asset_no = clean_value(row.iloc[2])  # 관리번호
        consumable_code = clean_value(row.iloc[5])  # 토너
        
        if not asset_no or not consumable_code:
            continue
        
        if not str(asset_no).startswith('KHP'):
            continue
        
        # 각 월별 컬럼 확인
        for col_idx, (year, month) in year_month_map.items():
            cell_value = row.iloc[col_idx]
            days = parse_day_from_cell(cell_value)
            
            for day in days:
                try:
                    replace_date = f"{year}-{month:02d}-{day:02d}"
                    
                    history = {
                        'asset_no': asset_no,  # equipment_id로 변환 필요
                        'consumable_code': consumable_code,  # consumable_id로 변환 필요
                        'replace_date': replace_date,
                        'quantity': 1,
                        'note': None,
                    }
                    results.append(history)
                except ValueError:
                    # 잘못된 날짜 무시
                    continue
    
    return results


def get_consumable_stats(history: List[Dict]) -> Dict:
    """소모품 사용 통계 생성"""
    stats = {
        'total_replacements': len(history),
        'by_consumable': {},
        'by_equipment': {},
        'by_year': {},
    }
    
    for h in history:
        code = h['consumable_code']
        asset = h['asset_no']
        year = h['replace_date'][:4] if h['replace_date'] else None
        
        # 소모품별 통계
        if code not in stats['by_consumable']:
            stats['by_consumable'][code] = 0
        stats['by_consumable'][code] += 1
        
        # 장비별 통계
        if asset not in stats['by_equipment']:
            stats['by_equipment'][asset] = 0
        stats['by_equipment'][asset] += 1
        
        # 연도별 통계
        if year:
            if year not in stats['by_year']:
                stats['by_year'][year] = 0
            stats['by_year'][year] += 1
    
    return stats
