# -*- coding: utf-8 -*-
"""
소프트웨어 라이선스(software_license) 및 설치 현황(sw_installation) 파서
- 03소프트웨어현황.xlsx
"""

import pandas as pd
import re
from typing import List, Dict, Tuple
from .common import clean_value, parse_date, to_int, read_excel_sheet


# SW 컬럼명 목록 (종합 시트)
SW_COLUMNS = ['Office', '한글', 'PDF편집', 'AutoCad', 'Inventor', 'Cam350', 'Rhinoceros', 'MiniTab', 'Photoshop']


def parse_sw_name_version(full_name: str) -> Tuple[str, str]:
    """
    소프트웨어 전체명에서 이름과 버전 분리
    예: "Microsoft Office Standard 2019 - ko-kr" → ("Microsoft Office Standard", "2019")
    """
    if not full_name:
        return None, None
    
    full_name = str(full_name).strip()
    
    # 연도 패턴 찾기 (2007, 2010, 2016, 2019, 2021 등)
    match = re.search(r'(\d{4})', full_name)
    if match:
        version = match.group(1)
        # 버전 이전까지를 이름으로
        name = full_name[:match.start()].strip()
        if name.endswith('-'):
            name = name[:-1].strip()
        return name, version
    
    return full_name, None


def parse_software_license_from_list(filepath: str) -> List[Dict]:
    """03소프트웨어현황 - 라이선스LIST 시트에서 라이선스 파싱"""
    df = read_excel_sheet(filepath, '라이선스LIST', header_row=1)
    
    results = []
    for _, row in df.iterrows():
        full_name = clean_value(row.iloc[1])  # 소프트웨어-버전
        qty = to_int(row.iloc[2])  # Copy
        
        if not full_name or full_name == '소프트웨어-버전':
            continue
        
        sw_name, sw_version = parse_sw_name_version(full_name)
        
        license_record = {
            'sw_name': sw_name,
            'sw_version': sw_version,
            'license_type': '영구',
            'license_key': None,
            'total_qty': qty if qty else 1,
            'purchase_date': None,
            'expire_date': None,
            'vendor': None,
            'note': clean_value(row.iloc[4]) if len(row) > 4 else None,
        }
        results.append(license_record)
    
    return results


def parse_software_license_from_master(filepath: str) -> List[Dict]:
    """03소프트웨어현황 - SW관리대장 시트에서 라이선스 파싱"""
    try:
        df = read_excel_sheet(filepath, 'SW관리대장', header_row=0)
    except:
        return []
    
    results = []
    for _, row in df.iterrows():
        sw_name = clean_value(row.get('프로그램명'))
        
        if not sw_name:
            continue
        
        license_record = {
            'sw_name': sw_name,
            'sw_version': None,
            'license_type': '영구',
            'license_key': clean_value(row.get('일련번호')),
            'total_qty': 1,
            'purchase_date': parse_date(row.get('구입년도')),
            'expire_date': None,
            'vendor': None,
            'note': clean_value(row.get('비고')),
        }
        results.append(license_record)
    
    return results


def parse_all_software_license(filepath: str) -> List[Dict]:
    """모든 소프트웨어 라이선스 파싱"""
    licenses = []
    
    # 라이선스LIST
    licenses.extend(parse_software_license_from_list(filepath))
    
    # SW관리대장 (있는 경우)
    licenses.extend(parse_software_license_from_master(filepath))
    
    # 중복 제거 (sw_name + sw_version 기준으로 수량 합산)
    license_map = {}
    for lic in licenses:
        key = (lic['sw_name'], lic['sw_version'])
        if key in license_map:
            # 수량 합산
            license_map[key]['total_qty'] += lic['total_qty']
            # license_key가 있으면 업데이트
            if lic['license_key']:
                license_map[key]['license_key'] = lic['license_key']
        else:
            license_map[key] = lic.copy()
    
    return list(license_map.values())


def parse_sw_installation(filepath: str) -> List[Dict]:
    """03소프트웨어현황 - 종합 시트에서 SW 설치 현황 파싱"""
    df = read_excel_sheet(filepath, '종합', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        emp_no = row.get('사번')
        name = clean_value(row.get('성명'))
        
        if not name or pd.isna(emp_no):
            continue
        
        # 사번 정규화
        if isinstance(emp_no, (int, float)):
            emp_no = f"{int(emp_no):05d}"
        else:
            emp_no = str(emp_no).strip().zfill(5)
        
        # 각 SW 컬럼 확인
        for sw_col in SW_COLUMNS:
            sw_value = clean_value(row.get(sw_col))
            if sw_value:
                installation = {
                    'emp_no': emp_no,  # user_id로 변환 필요
                    'user_name': name,
                    'asset_no': None,  # equipment_id로 변환 필요 (사용자-장비 매핑 필요)
                    'sw_name': sw_value,  # license_id로 변환 필요
                    'sw_category': sw_col,  # 원본 컬럼명 (Office, 한글 등)
                    'install_date': None,
                    'is_active': True,
                    'note': None,
                }
                results.append(installation)
    
    return results


def match_installation_to_license(installations: List[Dict], licenses: List[Dict]) -> List[Dict]:
    """설치 현황을 라이선스와 매칭"""
    # 라이선스 검색 맵 생성
    license_map = {}
    for lic in licenses:
        sw_name = lic['sw_name']
        if sw_name:
            # 전체 이름으로 매칭
            license_map[sw_name.lower()] = lic
            # 부분 이름으로도 매칭 (Office, 한글 등)
            for keyword in ['office', '한글', 'autocad', 'inventor', 'cam350', 'rhinoceros', 'minitab', 'photoshop', 'pdf']:
                if keyword in sw_name.lower():
                    if keyword not in license_map:
                        license_map[keyword] = lic
    
    matched = []
    for inst in installations:
        sw_name = inst['sw_name']
        if not sw_name:
            continue
        
        # 매칭 시도
        sw_name_lower = sw_name.lower()
        matched_license = None
        
        # 전체 이름 매칭
        if sw_name_lower in license_map:
            matched_license = license_map[sw_name_lower]
        else:
            # 키워드 매칭
            for keyword in license_map:
                if keyword in sw_name_lower:
                    matched_license = license_map[keyword]
                    break
        
        inst['matched_license'] = matched_license
        matched.append(inst)
    
    return matched
