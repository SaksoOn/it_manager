# -*- coding: utf-8 -*-
"""
공통 유틸리티 함수
"""

import pandas as pd
import re
from datetime import datetime
from typing import Optional, Any


def clean_value(value: Any) -> Optional[str]:
    """NULL 및 빈 값 정제"""
    if pd.isna(value):
        return None
    if isinstance(value, str):
        value = value.strip()
        if value in ['', '-', 'NaN', 'nan', 'None']:
            return None
    return value


def parse_date(value: Any, default_day: int = 1) -> Optional[str]:
    """
    다양한 날짜 형식을 YYYY-MM-DD로 변환
    - YYYY.MM → YYYY-MM-01
    - YYYY.MM.DD → YYYY-MM-DD
    - datetime 객체 → YYYY-MM-DD
    """
    if pd.isna(value) or value is None:
        return None
    
    # datetime 객체인 경우
    if isinstance(value, datetime):
        return value.strftime('%Y-%m-%d')
    
    if isinstance(value, pd.Timestamp):
        return value.strftime('%Y-%m-%d')
    
    value = str(value).strip()
    if not value or value in ['-', 'NaN', 'nan']:
        return None
    
    # YYYY.MM.DD 형식
    match = re.match(r'(\d{4})\.(\d{1,2})\.(\d{1,2})', value)
    if match:
        y, m, d = match.groups()
        return f"{y}-{int(m):02d}-{int(d):02d}"
    
    # YYYY.MM 형식
    match = re.match(r'(\d{4})\.(\d{1,2})', value)
    if match:
        y, m = match.groups()
        return f"{y}-{int(m):02d}-{default_day:02d}"
    
    # YYYY-MM-DD 형식 (이미 올바른 형식)
    match = re.match(r'(\d{4})-(\d{1,2})-(\d{1,2})', value)
    if match:
        y, m, d = match.groups()
        return f"{y}-{int(m):02d}-{int(d):02d}"
    
    return None


def parse_day_from_cell(value: Any) -> list:
    """
    셀 값에서 일자 추출 (토너 교체일 파싱용)
    - "25일" → [25]
    - "4일, 22일" → [4, 22]
    """
    if pd.isna(value) or value is None:
        return []
    
    value = str(value).strip()
    if not value:
        return []
    
    # 숫자 + '일' 패턴 찾기
    days = re.findall(r'(\d{1,2})일?', value)
    return [int(d) for d in days]


def to_int(value: Any) -> Optional[int]:
    """정수 변환"""
    if pd.isna(value) or value is None:
        return None
    try:
        return int(float(value))
    except (ValueError, TypeError):
        return None


def to_bool(value: Any, true_values: list = ['O', 'o', 'Y', 'y', '1', 'TRUE', 'True', 'true']) -> Optional[bool]:
    """불린 변환"""
    if pd.isna(value) or value is None:
        return None
    return str(value).strip() in true_values


def extract_category_from_asset_no(asset_no: str) -> Optional[str]:
    """관리번호에서 장비 카테고리 추출"""
    from config import EQUIPMENT_CATEGORY_MAP
    
    if not asset_no:
        return None
    
    for prefix, category in EQUIPMENT_CATEGORY_MAP.items():
        if asset_no.startswith(prefix):
            return category
    return '기타'


def extract_subcategory(identifier: str) -> Optional[str]:
    """구분자에서 세부 카테고리 추출"""
    if not identifier:
        return None
    
    identifier = str(identifier).upper()
    
    if 'L3' in identifier:
        return 'L3스위치'
    if 'L2' in identifier:
        return 'L2스위치'
    if 'FIREWALL' in identifier:
        return '방화벽'
    if 'NAS' in identifier:
        return 'NAS'
    if 'SWITCH' in identifier or 'SWITHC' in identifier:
        return '스위치'
    
    return None


def normalize_location(location: str) -> Optional[str]:
    """위치 정규화"""
    if not location:
        return None
    
    location = str(location).strip()
    
    # 3F → 3층
    match = re.match(r'(\d)F', location, re.IGNORECASE)
    if match:
        return f"{match.group(1)}층"
    
    return location


def read_excel_sheet(filepath: str, sheet_name: str, header_row: int = 0, engine: str = 'openpyxl') -> pd.DataFrame:
    """Excel 시트 읽기"""
    try:
        df = pd.read_excel(filepath, sheet_name=sheet_name, header=header_row, engine=engine)
        return df
    except Exception as e:
        print(f"Error reading {filepath} - {sheet_name}: {e}")
        return pd.DataFrame()


def generate_asset_no(prefix: str, year: int, seq: int) -> str:
    """관리번호 생성"""
    return f"{prefix}-{year % 100:02d}-{seq:03d}"
