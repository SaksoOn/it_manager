# -*- coding: utf-8 -*-
"""
사용자(users) 및 인증정보(credentials) 테이블 파서
- users: 03소프트웨어현황.xlsx (종합)
- user_credential: 02IP-MAC관리.xlsx (V10-DHCP)
- equipment_credential: 02IP-MAC관리.xlsx (허용불가MAC, 서버 및 장비)
"""

import pandas as pd
from typing import List, Dict, Tuple
from .common import clean_value, read_excel_sheet


def parse_users_from_software(filepath: str) -> List[Dict]:
    """03소프트웨어현황 - 종합 시트에서 사용자 파싱"""
    df = read_excel_sheet(filepath, '종합', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        emp_no = row.get('사번')
        name = clean_value(row.get('성명'))
        
        if not name or pd.isna(emp_no):
            continue
        
        # 사번 정규화 (숫자를 문자열로, 5자리로 패딩)
        if isinstance(emp_no, (int, float)):
            emp_no = f"{int(emp_no):05d}"
        else:
            emp_no = str(emp_no).strip().zfill(5)
        
        user = {
            'emp_no': emp_no,
            'name': name,
            'department': clean_value(row.get('부서')),
            'position': clean_value(row.get('직책')),
            'location_type': clean_value(row.get('위치')),
            'status': '재직',
        }
        results.append(user)
    
    return results


def parse_users_from_ip_mac(filepath: str) -> List[Dict]:
    """02IP-MAC관리 - V10-DHCP 시트에서 사용자 보조 파싱"""
    df = read_excel_sheet(filepath, 'V10-DHCP', header_row=2)
    
    results = []
    for _, row in df.iterrows():
        name = clean_value(row.get('사용자'))
        
        if not name or name in ['L3 Switch', 'L2 Switch']:
            continue
        
        # 이미 종합 시트에 있을 수 있으므로 기본 정보만
        user = {
            'emp_no': None,  # 나중에 매칭 필요
            'name': name,
            'department': None,
            'position': None,
            'location_type': '사내',
            'status': '재직',
        }
        results.append(user)
    
    return results


def parse_user_credentials(filepath: str) -> List[Dict]:
    """02IP-MAC관리에서 사용자 인증정보 파싱"""
    df = read_excel_sheet(filepath, 'V10-DHCP', header_row=2)
    
    results = []
    for _, row in df.iterrows():
        name = clean_value(row.get('사용자'))
        pc_id = clean_value(row.get('PC ID') or row.get(5))
        pc_pw = clean_value(row.get('PC PW') or row.get(6))
        email_id = clean_value(row.get('메일 ID') or row.get(7))
        email_pw = clean_value(row.get('메일 PW') or row.get(8))
        
        if not name or (not pc_id and not email_id):
            continue
        
        credential = {
            'user_name': name,  # user_id로 변환 필요
            'pc_id': pc_id,
            'pc_pw': pc_pw,
            'email_id': email_id,
            'email_pw': email_pw,
            'note': None,
        }
        results.append(credential)
    
    return results


def parse_equipment_credentials_from_mac(filepath: str) -> List[Dict]:
    """02IP-MAC관리 - 허용불가MAC 시트에서 장비 인증정보 파싱"""
    df = read_excel_sheet(filepath, '허용불가MAC', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        asset_no = clean_value(row.get('기기번호'))
        bios_pw = clean_value(row.get('BIOS PW'))
        bitlocker_pw = clean_value(row.get('BITLOCKER PW'))
        kensington = clean_value(row.get('Kensington Lock'))
        
        if not asset_no:
            continue
        
        if not bios_pw and not bitlocker_pw and not kensington:
            continue
        
        credential = {
            'asset_no': asset_no,  # equipment_id로 변환 필요
            'bios_pw': bios_pw,
            'bitlocker_pw': bitlocker_pw,
            'kensington_lock': kensington,
            'admin_id': None,
            'admin_pw': None,
            'note': None,
        }
        results.append(credential)
    
    return results


def parse_equipment_credentials_from_server(filepath: str) -> List[Dict]:
    """02IP-MAC관리 - 서버 및 장비 시트에서 서버 인증정보 파싱"""
    df = read_excel_sheet(filepath, '서버 및 장비', header_row=0)
    
    results = []
    for idx, row in df.iterrows():
        kind = clean_value(row.get('종류'))
        if kind != 'SVR':
            continue
        
        name = clean_value(row.get('명칭'))
        # 로그인 정보는 컬럼 위치로 접근
        admin_id = clean_value(row.iloc[12]) if len(row) > 12 else None  # 로그인 ID
        admin_pw = clean_value(row.iloc[13]) if len(row) > 13 else None  # 로그인 PW
        
        if not admin_id:
            continue
        
        asset_no = f"KHS-SVR-{idx+1:03d}"
        
        credential = {
            'asset_no': asset_no,
            'bios_pw': None,
            'bitlocker_pw': None,
            'kensington_lock': None,
            'admin_id': admin_id,
            'admin_pw': admin_pw,
            'note': name,
        }
        results.append(credential)
    
    return results


def parse_all_users(software_file: str, ip_mac_file: str) -> Tuple[List[Dict], List[Dict]]:
    """
    모든 사용자 데이터 통합 파싱
    Returns: (users, user_credentials)
    """
    # 주요 원본: 소프트웨어현황
    users = parse_users_from_software(software_file)
    
    # 이름 기준으로 중복 제거
    seen_names = {u['name'] for u in users}
    
    # IP-MAC에서 추가 사용자 (없는 경우만)
    ip_users = parse_users_from_ip_mac(ip_mac_file)
    for u in ip_users:
        if u['name'] not in seen_names:
            users.append(u)
            seen_names.add(u['name'])
    
    # 인증정보
    credentials = parse_user_credentials(ip_mac_file)
    
    return users, credentials


def parse_all_equipment_credentials(ip_mac_file: str) -> List[Dict]:
    """모든 장비 인증정보 통합 파싱"""
    credentials = []
    
    # 허용불가MAC 시트
    credentials.extend(parse_equipment_credentials_from_mac(ip_mac_file))
    
    # 서버 및 장비 시트
    credentials.extend(parse_equipment_credentials_from_server(ip_mac_file))
    
    return credentials
