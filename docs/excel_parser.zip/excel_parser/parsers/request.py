# -*- coding: utf-8 -*-
"""
IT 업무 의뢰(it_request) 파서
- 06전산업무의뢰서접수.xlsx
"""

import pandas as pd
from typing import List, Dict
from .common import clean_value, parse_date, read_excel_sheet


# 카테고리 컬럼 인덱스 매핑
CATEGORY_COLUMNS = {
    5: '신규개발',
    6: '기능개선', 
    7: '오류수정',
    8: '구입',
    9: '수리',
    10: '기타',
}


def parse_it_request_from_sheet(filepath: str, sheet_name: str) -> List[Dict]:
    """특정 시트에서 IT 업무 의뢰 파싱"""
    df = read_excel_sheet(filepath, sheet_name, header_row=0)
    
    results = []
    for _, row in df.iterrows():
        request_no = clean_value(row.iloc[1])  # 접수번호
        
        if not request_no or 'KHIT' not in str(request_no):
            continue
        
        requester = clean_value(row.iloc[2])  # 의뢰자
        request_date = parse_date(row.iloc[3])  # 의뢰일자
        complete_date = parse_date(row.iloc[4])  # 완료일자
        
        # 카테고리 판별 (O 표시된 컬럼)
        category = None
        for col_idx, cat_name in CATEGORY_COLUMNS.items():
            if col_idx < len(row):
                cell_value = clean_value(row.iloc[col_idx])
                if cell_value and cell_value.upper() == 'O':
                    category = cat_name
                    break
        
        content = clean_value(row.iloc[11])  # 의뢰내용
        action = clean_value(row.iloc[12])  # 조치내용
        
        # 상태 결정
        if complete_date:
            status = '완료'
        elif request_date:
            status = '진행중'
        else:
            status = '접수'
        
        # 의뢰내용 길이에 따라 title/content 분리
        title = None
        full_content = None
        if content:
            if len(content) <= 100:
                title = content
            else:
                title = content[:100] + '...'
                full_content = content
        
        request = {
            'request_no': request_no,
            'request_type': sheet_name,  # KHERP, VNERP, ETC
            'requester': requester,
            'request_date': request_date,
            'complete_date': complete_date,
            'category': category,
            'title': title,
            'content': full_content,
            'status': status,
            'handler': None,
            'note': action,
        }
        results.append(request)
    
    return results


def parse_all_it_requests(filepath: str) -> List[Dict]:
    """모든 IT 업무 의뢰 파싱"""
    all_requests = []
    
    for sheet_name in ['KHERP', 'VNERP', 'ETC']:
        try:
            requests = parse_it_request_from_sheet(filepath, sheet_name)
            all_requests.extend(requests)
        except Exception as e:
            print(f"Warning: Failed to parse {sheet_name}: {e}")
    
    # 접수번호 기준 정렬
    all_requests.sort(key=lambda x: x['request_no'] or '')
    
    return all_requests


def get_request_stats(requests: List[Dict]) -> Dict:
    """IT 요청 통계 생성"""
    stats = {
        'total': len(requests),
        'by_type': {},
        'by_status': {},
        'by_category': {},
        'by_requester': {},
    }
    
    for req in requests:
        # 타입별
        req_type = req['request_type']
        if req_type not in stats['by_type']:
            stats['by_type'][req_type] = 0
        stats['by_type'][req_type] += 1
        
        # 상태별
        status = req['status']
        if status not in stats['by_status']:
            stats['by_status'][status] = 0
        stats['by_status'][status] += 1
        
        # 카테고리별
        category = req['category']
        if category:
            if category not in stats['by_category']:
                stats['by_category'][category] = 0
            stats['by_category'][category] += 1
        
        # 의뢰자별
        requester = req['requester']
        if requester:
            if requester not in stats['by_requester']:
                stats['by_requester'][requester] = 0
            stats['by_requester'][requester] += 1
    
    return stats
