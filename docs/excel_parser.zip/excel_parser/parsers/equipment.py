# -*- coding: utf-8 -*-
"""
장비(equipment) 테이블 파서
- PC/노트북: 02IP-MAC관리.xlsx (V10-DHCP, V10-고정대역)
- 서버: 02IP-MAC관리.xlsx (서버 및 장비)
- 프린터: 01프린트관리대장.xlsx (관리대장)
"""

import pandas as pd
from typing import List, Dict
from .common import (
    clean_value, parse_date, to_int, 
    extract_category_from_asset_no, extract_subcategory,
    normalize_location, read_excel_sheet
)


def parse_equipment_from_dhcp(filepath: str) -> List[Dict]:
    """V10-DHCP 시트에서 노트북/PC 파싱"""
    df = read_excel_sheet(filepath, 'V10-DHCP', header_row=2)
    
    results = []
    for _, row in df.iterrows():
        asset_no = clean_value(row.get('관리번호') or row.get(12))
        if not asset_no or not str(asset_no).startswith('KH'):
            continue
        
        equipment = {
            'asset_no': asset_no,
            'category': '노트북',
            'sub_category': None,
            'model_name': clean_value(row.get('모델명') or row.get('12.1')),
            'serial_no': clean_value(row.get('S/N') or row.get(11)),
            'purchase_date': parse_date(row.get('구매년월') or row.get(10)),
            'status': '사용중',
            'location': None,
            'department': None,
            'os': clean_value(row.get('OS') or row.get(13)),
            'cpu': clean_value(row.get('CPU') or row.get(16)),
            'memory': clean_value(row.get('메모리') or row.get(17)),
            'storage': clean_value(row.get('용량') or row.get(18)),
            'note': clean_value(row.get('비고')),
        }
        results.append(equipment)
    
    return results


def parse_equipment_from_fixed(filepath: str) -> List[Dict]:
    """V10-고정대역 시트에서 네트워크 장비 파싱"""
    df = read_excel_sheet(filepath, 'V10-고정대역', header_row=2)
    
    results = []
    for _, row in df.iterrows():
        asset_no = clean_value(row.get('관리번호') or row.get(9))
        identifier = clean_value(row.get('구분자') or row.get(2))
        
        if not asset_no:
            continue
        
        # 카테고리 판단
        category = extract_category_from_asset_no(str(asset_no))
        if identifier:
            if 'Switch' in str(identifier) or 'Swithc' in str(identifier):
                category = '네트워크'
            elif 'FIREWALL' in str(identifier).upper():
                category = '네트워크'
        
        equipment = {
            'asset_no': asset_no,
            'category': category,
            'sub_category': extract_subcategory(identifier),
            'model_name': clean_value(row.get('모델명') or row.get(12)),
            'serial_no': clean_value(row.get('S/N') or row.get(11)),
            'purchase_date': parse_date(row.get('구매년월') or row.get(10)),
            'status': '사용중',
            'location': None,
            'department': None,
            'os': clean_value(row.get('OS') or row.get(13)),
            'cpu': clean_value(row.get('CPU') or row.get(16)),
            'memory': clean_value(row.get('메모리') or row.get(17)),
            'storage': clean_value(row.get('용량') or row.get(18)),
            'note': clean_value(row.get('비고')),
        }
        results.append(equipment)
    
    return results


def parse_equipment_from_server(filepath: str) -> List[Dict]:
    """서버 및 장비 시트에서 서버 파싱"""
    df = read_excel_sheet(filepath, '서버 및 장비', header_row=0)
    
    results = []
    for idx, row in df.iterrows():
        kind = clean_value(row.get('종류'))
        if kind != 'SVR':
            continue
        
        name = clean_value(row.get('명칭'))
        model = clean_value(row.get('장비명'))
        
        if not name and not model:
            continue
        
        # 관리번호 생성 (없는 경우)
        asset_no = f"KHS-SVR-{idx+1:03d}"
        
        equipment = {
            'asset_no': asset_no,
            'category': '서버',
            'sub_category': None,
            'model_name': model,
            'serial_no': None,
            'purchase_date': parse_date(row.get('구매일')),
            'status': '사용중',
            'location': None,
            'department': clean_value(row.get('부서')),
            'os': clean_value(row.iloc[6]) if len(row) > 6 else None,  # OS 컬럼
            'cpu': clean_value(row.iloc[8]) if len(row) > 8 else None,  # CPU 컬럼
            'memory': None,
            'storage': None,
            'note': name,  # 명칭을 비고에 저장
        }
        results.append(equipment)
    
    return results


def parse_equipment_from_printer(filepath: str) -> List[Dict]:
    """프린트관리대장에서 프린터 파싱"""
    df = read_excel_sheet(filepath, '관리대장', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        # 첫 번째 열에서 위치(층), 두 번째에서 부서 등 추출
        location = clean_value(row.iloc[0])
        department = clean_value(row.iloc[1])
        asset_no = clean_value(row.iloc[2])
        model_name = clean_value(row.iloc[3])
        
        if not asset_no or not str(asset_no).startswith('KHP'):
            continue
        
        equipment = {
            'asset_no': asset_no,
            'category': '프린터',
            'sub_category': None,
            'model_name': model_name,
            'serial_no': None,
            'purchase_date': None,
            'status': '사용중',
            'location': normalize_location(location),
            'department': department,
            'os': None,
            'cpu': None,
            'memory': None,
            'storage': None,
            'note': None,
        }
        results.append(equipment)
    
    return results


def parse_all_equipment(ip_mac_file: str, printer_file: str) -> List[Dict]:
    """모든 장비 데이터 통합 파싱"""
    all_equipment = []
    
    # PC/노트북 (V10-DHCP)
    all_equipment.extend(parse_equipment_from_dhcp(ip_mac_file))
    
    # 네트워크 장비 (V10-고정대역)
    all_equipment.extend(parse_equipment_from_fixed(ip_mac_file))
    
    # 서버
    all_equipment.extend(parse_equipment_from_server(ip_mac_file))
    
    # 프린터
    all_equipment.extend(parse_equipment_from_printer(printer_file))
    
    # 중복 제거 (asset_no 기준)
    seen = set()
    unique_equipment = []
    for eq in all_equipment:
        if eq['asset_no'] not in seen:
            seen.add(eq['asset_no'])
            unique_equipment.append(eq)
    
    return unique_equipment
