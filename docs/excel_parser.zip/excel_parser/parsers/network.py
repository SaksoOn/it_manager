# -*- coding: utf-8 -*-
"""
IP 할당(ip_allocation), 방화벽 정책(network_policy), 무선 AP(wireless_ap) 파서
- 02IP-MAC관리.xlsx
"""

import pandas as pd
from typing import List, Dict
from .common import clean_value, to_bool, read_excel_sheet


def parse_ip_allocation_from_sheet(filepath: str, sheet_name: str, network_zone: str, allocation_type: str) -> List[Dict]:
    """특정 시트에서 IP 할당 정보 파싱"""
    df = read_excel_sheet(filepath, sheet_name, header_row=2)
    
    results = []
    for _, row in df.iterrows():
        ip_address = clean_value(row.get('IP') or row.iloc[1])
        
        if not ip_address or not str(ip_address).replace('.', '').replace(' ', '').isdigit():
            # IP 형식이 아닌 경우 건너뛰기
            if ip_address and '192.168' not in str(ip_address) and '172.16' not in str(ip_address):
                continue
        
        if not ip_address:
            continue
        
        mac_address = clean_value(row.get('MAC(유선)') or row.get(14))
        description = clean_value(row.get('사용자'))
        asset_no = clean_value(row.get('관리번호') or row.get(12) or row.get(9))
        
        ip_record = {
            'ip_address': str(ip_address).strip(),
            'mac_address': mac_address,
            'network_zone': network_zone,
            'allocation_type': allocation_type,
            'asset_no': asset_no,  # equipment_id로 변환 필요
            'description': description,
            'is_active': True,
        }
        results.append(ip_record)
    
    return results


def parse_all_ip_allocation(filepath: str) -> List[Dict]:
    """모든 IP 할당 정보 파싱"""
    all_ips = []
    
    # V10-DHCP
    all_ips.extend(parse_ip_allocation_from_sheet(filepath, 'V10-DHCP', 'V10-DHCP', 'DHCP'))
    
    # V10-고정대역
    all_ips.extend(parse_ip_allocation_from_sheet(filepath, 'V10-고정대역', 'V10-고정', '고정'))
    
    # V40-폐쇄망
    all_ips.extend(parse_ip_allocation_from_sheet(filepath, 'V40-폐쇄망', 'V40-폐쇄망', 'DHCP'))
    
    # V50-DHCP (Guest)
    all_ips.extend(parse_ip_allocation_from_sheet(filepath, 'V50-DHCP', 'V50-Guest', 'DHCP'))
    
    # 2공장
    all_ips.extend(parse_ip_allocation_from_sheet(filepath, '2공장', '2공장', 'DHCP'))
    
    # 중복 제거 (ip_address 기준)
    seen = set()
    unique_ips = []
    for ip in all_ips:
        if ip['ip_address'] not in seen:
            seen.add(ip['ip_address'])
            unique_ips.append(ip)
    
    return unique_ips


def parse_network_policy(filepath: str) -> List[Dict]:
    """방화벽정책 시트에서 네트워크 정책 파싱"""
    df = read_excel_sheet(filepath, '방화벽정책', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        policy_no = clean_value(row.iloc[1])  # 구분 번호
        
        # 헤더 행 건너뛰기
        if policy_no == '구분' or not policy_no:
            continue
        
        try:
            policy_no = int(float(policy_no))
        except:
            continue
        
        external = clean_value(row.iloc[2])  # 외부
        internal = clean_value(row.iloc[3])  # 내부
        
        direction = f"{external}→{internal}" if external and internal else None
        
        policy = {
            'policy_no': policy_no,
            'direction': direction,
            'source_ip': clean_value(row.iloc[4]),  # 출발지 IP
            'source_desc': clean_value(row.iloc[5]),  # 출발지IP설명
            'dest_public_ip': clean_value(row.iloc[6]),  # 목적지 공인 IP
            'dest_private_ip': clean_value(row.iloc[7]),  # 목적지 사설 IP
            'dest_desc': clean_value(row.iloc[8]),  # 목적지IP설명
            'service': clean_value(row.iloc[9]),  # 오픈서비스
            'action': clean_value(row.iloc[10]),  # 허용 차단
            'is_enabled': True,
            'note': None,
        }
        
        if policy['action'] in ['Allow', 'Deny']:
            results.append(policy)
    
    return results


def parse_wireless_ap(filepath: str) -> List[Dict]:
    """무선LIST 시트에서 무선 AP 파싱"""
    df = read_excel_sheet(filepath, '무선LIST', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        location = clean_value(row.iloc[0])  # 설치장소
        ssid = clean_value(row.iloc[3])  # 공유기명
        asset_no = clean_value(row.iloc[11])  # 비고 (KHE-WF-xxx)
        
        # 헤더 행 건너뛰기
        if location == '설치장소' or not location:
            continue
        
        # 숫자만 있는 행 건너뛰기 (층 구분 숫자)
        if str(location).isdigit():
            continue
        
        model = clean_value(row.iloc[5])  # 모델
        ip_address = clean_value(row.iloc[6])  # IP
        support_gigabit = to_bool(row.iloc[7])  # Gbps 지원
        support_5g = to_bool(row.iloc[8])  # 5G 지원
        speed_info = clean_value(row.iloc[12])  # 상세속도
        replace_check = clean_value(row.iloc[10])  # 교체검토
        
        # 상태 결정
        status = '교체검토' if replace_check else '사용중'
        
        ap = {
            'asset_no': asset_no if asset_no else f"AP-{len(results)+1:03d}",
            'location': location,
            'ssid': ssid,
            'model': model,
            'ip_address': ip_address,
            'support_5g': support_5g,
            'support_gigabit': support_gigabit,
            'speed_info': speed_info,
            'status': status,
            'note': None,
        }
        results.append(ap)
    
    return results
