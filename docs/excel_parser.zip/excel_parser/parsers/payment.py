# -*- coding: utf-8 -*-
"""
정기지불/품의(payment) 및 정기지불 항목(regular_payment) 파서
- 05전산실정기지불자료.xlsx
"""

import pandas as pd
from typing import List, Dict
from .common import clean_value, parse_date, to_int, read_excel_sheet


def parse_payment(filepath: str) -> List[Dict]:
    """05전산실정기지불자료 - 상세내용 시트에서 지출 내역 파싱"""
    df = read_excel_sheet(filepath, '상세내용', header_row=0)
    
    results = []
    for _, row in df.iterrows():
        payment_date = parse_date(row.iloc[0])  # 일자
        
        if not payment_date:
            continue
        
        category = clean_value(row.iloc[1])  # 대분류 (품의/물품)
        
        # 헤더 행 건너뛰기
        if category in ['대분류', None]:
            continue
        
        account = clean_value(row.iloc[2])  # 계정과목
        item_name = clean_value(row.iloc[3])  # 규격 (품목명으로 사용)
        quantity = to_int(row.iloc[4])  # 수량
        unit_price = to_int(row.iloc[5])  # 단가
        amount = to_int(row.iloc[6])  # 금액
        note = clean_value(row.iloc[7])  # 비고
        
        if not amount:
            continue
        
        payment = {
            'payment_no': None,
            'payment_date': payment_date,
            'category': category if category in ['품의', '물품'] else '품의',
            'account': account,
            'item_name': item_name,
            'specification': None,
            'quantity': quantity,
            'unit_price': unit_price,
            'amount': amount,
            'vendor': None,
            'status': 'OK',
            'note': note,
        }
        results.append(payment)
    
    return results


def parse_regular_payment(filepath: str) -> List[Dict]:
    """05전산실정기지불자료 - 정기지불리스트 시트에서 정기지불 항목 파싱"""
    df = read_excel_sheet(filepath, '정기지불리스트', header_row=0)
    
    results = []
    current_vendor = None
    
    for _, row in df.iterrows():
        vendor = clean_value(row.iloc[0])  # 업체
        item_name = clean_value(row.iloc[1])  # 항목
        
        # 헤더 행 건너뛰기
        if vendor == '업체' or item_name == '항목':
            continue
        
        # 업체가 비어있으면 이전 업체 사용 (병합 셀 대응)
        if vendor:
            current_vendor = vendor
        else:
            vendor = current_vendor
        
        if not item_name:
            continue
        
        base_price = to_int(row.iloc[2])  # 이용료
        discount = to_int(row.iloc[3])  # 할인금액
        vat = to_int(row.iloc[4])  # 부가세
        total_price = to_int(row.iloc[5])  # 지불금액
        billing_type = clean_value(row.iloc[6])  # 청구
        manager = clean_value(row.iloc[7])  # 담당자
        note = clean_value(row.iloc[8])  # 비고
        
        if not total_price:
            continue
        
        regular = {
            'vendor': vendor,
            'item_name': item_name,
            'base_price': base_price,
            'discount': discount,
            'vat': vat,
            'total_price': total_price,
            'billing_type': billing_type,
            'manager': manager,
            'note': note,
            'is_active': True,
        }
        results.append(regular)
    
    return results


def get_payment_stats(payments: List[Dict]) -> Dict:
    """지출 통계 생성"""
    stats = {
        'total_count': len(payments),
        'total_amount': sum(p['amount'] for p in payments if p['amount']),
        'by_category': {},
        'by_account': {},
        'by_year': {},
    }
    
    for p in payments:
        amount = p['amount'] or 0
        
        # 카테고리별
        category = p['category']
        if category not in stats['by_category']:
            stats['by_category'][category] = {'count': 0, 'amount': 0}
        stats['by_category'][category]['count'] += 1
        stats['by_category'][category]['amount'] += amount
        
        # 계정과목별
        account = p['account']
        if account:
            if account not in stats['by_account']:
                stats['by_account'][account] = {'count': 0, 'amount': 0}
            stats['by_account'][account]['count'] += 1
            stats['by_account'][account]['amount'] += amount
        
        # 연도별
        if p['payment_date']:
            year = p['payment_date'][:4]
            if year not in stats['by_year']:
                stats['by_year'][year] = {'count': 0, 'amount': 0}
            stats['by_year'][year]['count'] += 1
            stats['by_year'][year]['amount'] += amount
    
    return stats


def get_regular_payment_summary(regular_payments: List[Dict]) -> Dict:
    """정기지불 요약"""
    summary = {
        'total_items': len(regular_payments),
        'monthly_total': sum(r['total_price'] for r in regular_payments if r['total_price']),
        'by_vendor': {},
    }
    
    for r in regular_payments:
        vendor = r['vendor']
        if vendor:
            if vendor not in summary['by_vendor']:
                summary['by_vendor'][vendor] = {'items': [], 'total': 0}
            summary['by_vendor'][vendor]['items'].append(r['item_name'])
            summary['by_vendor'][vendor]['total'] += r['total_price'] or 0
    
    return summary
