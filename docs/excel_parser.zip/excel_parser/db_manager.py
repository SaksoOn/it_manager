# -*- coding: utf-8 -*-
"""
PostgreSQL 데이터베이스 삽입 모듈
"""

import os
from typing import List, Dict, Optional
from datetime import datetime

try:
    import psycopg2
    from psycopg2.extras import execute_values
    HAS_PSYCOPG2 = True
except ImportError:
    HAS_PSYCOPG2 = False


class DatabaseManager:
    """PostgreSQL 데이터베이스 관리 클래스"""
    
    def __init__(self, host: str = 'localhost', port: int = 5432, 
                 database: str = 'it_manager', user: str = 'postgres', password: str = ''):
        """
        DB 연결 초기화
        
        환경변수로 설정 가능:
        - DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
        """
        if not HAS_PSYCOPG2:
            raise ImportError("psycopg2 패키지가 필요합니다: pip install psycopg2-binary")
        
        self.config = {
            'host': os.getenv('DB_HOST', host),
            'port': int(os.getenv('DB_PORT', port)),
            'database': os.getenv('DB_NAME', database),
            'user': os.getenv('DB_USER', user),
            'password': os.getenv('DB_PASSWORD', password),
        }
        self.conn = None
        self.cursor = None
    
    def connect(self):
        """DB 연결"""
        self.conn = psycopg2.connect(**self.config)
        self.cursor = self.conn.cursor()
        print(f"✓ 데이터베이스 연결 성공: {self.config['database']}")
    
    def close(self):
        """DB 연결 종료"""
        if self.cursor:
            self.cursor.close()
        if self.conn:
            self.conn.close()
        print("✓ 데이터베이스 연결 종료")
    
    def commit(self):
        """트랜잭션 커밋"""
        if self.conn:
            self.conn.commit()
    
    def rollback(self):
        """트랜잭션 롤백"""
        if self.conn:
            self.conn.rollback()
    
    # ========================================
    # 데이터 삽입 메서드
    # ========================================
    
    def insert_equipment(self, equipment_list: List[Dict]) -> int:
        """장비 데이터 삽입"""
        if not equipment_list:
            return 0
        
        sql = """
            INSERT INTO equipment (asset_no, category, sub_category, model_name, serial_no, 
                                   purchase_date, status, location, department, os, cpu, memory, storage, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (asset_no) DO UPDATE SET
                category = EXCLUDED.category,
                model_name = EXCLUDED.model_name,
                updated_at = CURRENT_TIMESTAMP
            RETURNING equipment_id
        """
        
        count = 0
        for eq in equipment_list:
            try:
                self.cursor.execute(sql, (
                    eq['asset_no'], eq['category'], eq.get('sub_category'),
                    eq.get('model_name'), eq.get('serial_no'), eq.get('purchase_date'),
                    eq.get('status', '사용중'), eq.get('location'), eq.get('department'),
                    eq.get('os'), eq.get('cpu'), eq.get('memory'), eq.get('storage'), eq.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {eq.get('asset_no')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ equipment: {count}건 삽입/업데이트")
        return count
    
    def insert_users(self, users_list: List[Dict]) -> int:
        """사용자 데이터 삽입"""
        if not users_list:
            return 0
        
        sql = """
            INSERT INTO users (emp_no, name, department, position, location_type, status)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (emp_no) DO UPDATE SET
                name = EXCLUDED.name,
                department = EXCLUDED.department,
                updated_at = CURRENT_TIMESTAMP
            RETURNING user_id
        """
        
        count = 0
        for user in users_list:
            if not user.get('emp_no'):
                continue
            try:
                self.cursor.execute(sql, (
                    user['emp_no'], user['name'], user.get('department'),
                    user.get('position'), user.get('location_type'), user.get('status', '재직')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {user.get('name')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ users: {count}건 삽입/업데이트")
        return count
    
    def insert_ip_allocation(self, ip_list: List[Dict]) -> int:
        """IP 할당 데이터 삽입"""
        if not ip_list:
            return 0
        
        sql = """
            INSERT INTO ip_allocation (ip_address, mac_address, network_zone, allocation_type, 
                                        equipment_id, description, is_active)
            VALUES (%s, %s, %s, %s, 
                    (SELECT equipment_id FROM equipment WHERE asset_no = %s LIMIT 1),
                    %s, %s)
            ON CONFLICT (ip_address) DO UPDATE SET
                mac_address = EXCLUDED.mac_address,
                network_zone = EXCLUDED.network_zone,
                updated_at = CURRENT_TIMESTAMP
        """
        
        count = 0
        for ip in ip_list:
            try:
                self.cursor.execute(sql, (
                    ip['ip_address'], ip.get('mac_address'), ip['network_zone'],
                    ip['allocation_type'], ip.get('asset_no'),
                    ip.get('description'), ip.get('is_active', True)
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {ip.get('ip_address')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ ip_allocation: {count}건 삽입/업데이트")
        return count
    
    def insert_software_license(self, licenses: List[Dict]) -> int:
        """소프트웨어 라이선스 삽입"""
        if not licenses:
            return 0
        
        sql = """
            INSERT INTO software_license (sw_name, sw_version, license_type, license_key, 
                                          total_qty, purchase_date, expire_date, vendor, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING license_id
        """
        
        count = 0
        for lic in licenses:
            try:
                self.cursor.execute(sql, (
                    lic['sw_name'], lic.get('sw_version'), lic.get('license_type'),
                    lic.get('license_key'), lic.get('total_qty', 1),
                    lic.get('purchase_date'), lic.get('expire_date'),
                    lic.get('vendor'), lic.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {lic.get('sw_name')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ software_license: {count}건 삽입")
        return count
    
    def insert_printer_consumable(self, consumables: List[Dict]) -> int:
        """프린터 소모품 삽입"""
        if not consumables:
            return 0
        
        sql = """
            INSERT INTO printer_consumable (consumable_code, consumable_name, consumable_type, 
                                            compatible_models, unit_price)
            VALUES (%s, %s, %s, %s, %s)
            ON CONFLICT (consumable_code) DO UPDATE SET
                compatible_models = EXCLUDED.compatible_models
            RETURNING consumable_id
        """
        
        count = 0
        for con in consumables:
            try:
                self.cursor.execute(sql, (
                    con['consumable_code'], con.get('consumable_name'),
                    con.get('consumable_type', '토너'), con.get('compatible_models'),
                    con.get('unit_price')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {con.get('consumable_code')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ printer_consumable: {count}건 삽입/업데이트")
        return count
    
    def insert_consumable_history(self, history: List[Dict]) -> int:
        """소모품 교체 이력 삽입"""
        if not history:
            return 0
        
        sql = """
            INSERT INTO consumable_history (equipment_id, consumable_id, replace_date, quantity, note)
            SELECT 
                (SELECT equipment_id FROM equipment WHERE asset_no = %s LIMIT 1),
                (SELECT consumable_id FROM printer_consumable WHERE consumable_code = %s LIMIT 1),
                %s, %s, %s
            WHERE EXISTS (SELECT 1 FROM equipment WHERE asset_no = %s)
              AND EXISTS (SELECT 1 FROM printer_consumable WHERE consumable_code = %s)
        """
        
        count = 0
        for h in history:
            try:
                self.cursor.execute(sql, (
                    h['asset_no'], h['consumable_code'],
                    h['replace_date'], h.get('quantity', 1), h.get('note'),
                    h['asset_no'], h['consumable_code']
                ))
                if self.cursor.rowcount > 0:
                    count += 1
            except Exception as e:
                pass  # 중복 등 무시
        
        self.commit()
        print(f"  ✓ consumable_history: {count}건 삽입")
        return count
    
    def insert_it_request(self, requests: List[Dict]) -> int:
        """IT 요청 삽입"""
        if not requests:
            return 0
        
        sql = """
            INSERT INTO it_request (request_no, request_type, requester, request_date, 
                                    complete_date, category, title, content, status, handler, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (request_no) DO UPDATE SET
                status = EXCLUDED.status,
                complete_date = EXCLUDED.complete_date,
                updated_at = CURRENT_TIMESTAMP
        """
        
        count = 0
        for req in requests:
            try:
                self.cursor.execute(sql, (
                    req['request_no'], req['request_type'], req['requester'],
                    req.get('request_date'), req.get('complete_date'),
                    req.get('category'), req.get('title'), req.get('content'),
                    req.get('status', '접수'), req.get('handler'), req.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: {req.get('request_no')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ it_request: {count}건 삽입/업데이트")
        return count
    
    def insert_payment(self, payments: List[Dict]) -> int:
        """지출 내역 삽입"""
        if not payments:
            return 0
        
        sql = """
            INSERT INTO payment (payment_no, payment_date, category, account, item_name, 
                                 specification, quantity, unit_price, amount, vendor, status, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        count = 0
        for p in payments:
            try:
                self.cursor.execute(sql, (
                    p.get('payment_no'), p['payment_date'], p['category'],
                    p.get('account'), p['item_name'], p.get('specification'),
                    p.get('quantity'), p.get('unit_price'), p['amount'],
                    p.get('vendor'), p.get('status', 'OK'), p.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: 지출내역 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ payment: {count}건 삽입")
        return count
    
    def insert_regular_payment(self, regular_payments: List[Dict]) -> int:
        """정기지불 항목 삽입"""
        if not regular_payments:
            return 0
        
        sql = """
            INSERT INTO regular_payment (vendor, item_name, base_price, discount, vat, 
                                         total_price, billing_type, manager, note, is_active)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        count = 0
        for r in regular_payments:
            try:
                self.cursor.execute(sql, (
                    r['vendor'], r['item_name'], r.get('base_price'),
                    r.get('discount'), r.get('vat'), r['total_price'],
                    r.get('billing_type'), r.get('manager'), r.get('note'),
                    r.get('is_active', True)
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: 정기지불 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ regular_payment: {count}건 삽입")
        return count
    
    def insert_network_policy(self, policies: List[Dict]) -> int:
        """방화벽 정책 삽입"""
        if not policies:
            return 0
        
        sql = """
            INSERT INTO network_policy (policy_no, direction, source_ip, source_desc, 
                                        dest_public_ip, dest_private_ip, dest_desc, 
                                        service, action, is_enabled, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        count = 0
        for p in policies:
            try:
                self.cursor.execute(sql, (
                    p.get('policy_no'), p.get('direction'), p.get('source_ip'),
                    p.get('source_desc'), p.get('dest_public_ip'), p.get('dest_private_ip'),
                    p.get('dest_desc'), p.get('service'), p['action'],
                    p.get('is_enabled', True), p.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: 정책 {p.get('policy_no')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ network_policy: {count}건 삽입")
        return count
    
    def insert_wireless_ap(self, aps: List[Dict]) -> int:
        """무선 AP 삽입"""
        if not aps:
            return 0
        
        sql = """
            INSERT INTO wireless_ap (asset_no, location, ssid, model, ip_address, 
                                     support_5g, support_gigabit, speed_info, status, note)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (asset_no) DO UPDATE SET
                location = EXCLUDED.location,
                status = EXCLUDED.status,
                updated_at = CURRENT_TIMESTAMP
        """
        
        count = 0
        for ap in aps:
            try:
                self.cursor.execute(sql, (
                    ap['asset_no'], ap['location'], ap.get('ssid'),
                    ap.get('model'), ap.get('ip_address'),
                    ap.get('support_5g'), ap.get('support_gigabit'),
                    ap.get('speed_info'), ap.get('status', '사용중'), ap.get('note')
                ))
                count += 1
            except Exception as e:
                print(f"  Warning: AP {ap.get('asset_no')} 삽입 실패 - {e}")
        
        self.commit()
        print(f"  ✓ wireless_ap: {count}건 삽입/업데이트")
        return count
